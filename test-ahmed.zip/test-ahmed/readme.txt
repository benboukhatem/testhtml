===template test css ====

Contributors: ahmed ben boukhatem
Tags:  landing page, front-end builder
Requires html: 6
Requires css: 4.15
Requires JQuery: 3.7.1
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
== Description ==

create page test with css 4 , html 6 and javascript

section created :
*page home---
*--------- this css in layout.css----------------------------------------
section header

section footer

*section herosection-------------------------------------------------------
*--this css in slider.css
*for mobile open divice mobile in chrom after that you can test my application

***animation************************************

smooth scroller css

animation in menu
animation in filter -- btn "rechercher"
animation button slider
animation button article before the title
animation in the text "inscrivez-vous"
animation in button newslettre
animation in the social button 
animation in menu get way
animation in "nous joindre"

*************tablet partie *******************************
article forme

*************mobile form ********************************
new menu
article form
footer
	




 